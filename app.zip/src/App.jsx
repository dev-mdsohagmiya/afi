import Layout from "./Layout";
import "./styles/bootstrap/custom.css";
function App() {
  return (
    <>
      <div>
        <Layout />
      </div>
    </>
  );
}

export default App;
